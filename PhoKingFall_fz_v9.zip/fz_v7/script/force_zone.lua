#version 2

-- ============================================================
--  FORCE ZONE  —  Vehicle Sumo map asset  (v2)
--
--  HOW TO ADD TO YOUR MAP XML:
--
--  1. Drop the script tag once in your scene:
--       <script file="MOD/script/force_zone.lua"
--               param0="power=30 radius=8 respectGame=true"/>
--
--  2. Place location markers with tag "force_zone" wherever
--     you want a force zone. No vox needed — just like
--     crown_spawn or zone locations.
--       <location tags="force_zone" pos="0 6 0" rot="0 0 0"/>
--
--  ROTATION → PUSH DIRECTION  (local +Y is the push axis)
--  This matches how Teardown's built-in cannon works.
--
--    rot="0 0 0"      →  pushes straight UP   (+Y world)
--    rot="90 0 0"     →  pushes +Z  (south)
--    rot="-90 0 0"    →  pushes -Z  (north)
--    rot="0 0 -90"    →  pushes +X  (east/right)
--    rot="0 0 90"     →  pushes -X  (west/left)
--    rot="180 0 0"    →  pushes straight DOWN
--
--  TIP: In the Teardown editor, rotate the location arrow
--  so it points the direction you want to push, then add
--  90 degrees — or just test and eyeball it. The DebugLine
--  drawn in-editor shows you the push direction live.
--
--  PARAMETERS (in param0 on the script tag):
--    power        — force per second               (default 30)
--    radius       — sphere radius around the point (default 8)
--    respectGame  — wait for game to start         (default true)
--    tag          — location tag to search for     (default "force_zone")
--    debug        — draw direction arrows in editor (default true)
--
-- ============================================================

POWER        = GetFloatParam("power",       30)
RADIUS       = GetFloatParam("radius",       8)
RESPECT_GAME = GetBoolParam("respectGame", true)
ZONE_TAG     = GetStringParam("tag",   "force_zone")
DEBUG        = GetBoolParam("debug",       true)

zoneLocations = {}

function server.init()
    zoneLocations = FindLocations(ZONE_TAG, true)
end

function server.tick(dt)
    local gameStarted = GetBool("level.gameStarted", false)
    if RESPECT_GAME and not gameStarted then
        -- still draw debug arrows even when game hasn't started
        if DEBUG then drawDebug() end
        return
    end

    if #zoneLocations == 0 then return end

    for i = 1, #zoneLocations do
        local loc    = zoneLocations[i]
        local trans  = GetLocationTransform(loc)
        local center = trans.pos

        -- Local +Y is the push axis — matches VS cannon.lua convention.
        -- rot="0 0 0"  →  +Y world (up)
        -- rot="90 0 0" →  +Z world (south/forward)
        -- rot="0 0 -90"→  +X world (east/right)
        local pushDir = VecNormalize(TransformToParentVec(trans, Vec(0, 1, 0)))

        local r = RADIUS
        QueryRequire("dynamic")
        local bodies = QueryAabbBodies(
            VecSub(center, Vec(r, r, r)),
            VecAdd(center, Vec(r, r, r))
        )

        for j = 1, #bodies do
            local body    = bodies[j]
            local bodyPos = GetBodyTransform(body).pos
            local dist    = VecLength(VecSub(bodyPos, center))

            if dist <= RADIUS then
                local vel     = GetBodyVelocity(body)
                local impulse = VecScale(pushDir, POWER * dt)
                SetBodyVelocity(body, VecAdd(vel, impulse))
            end
        end
    end

    if DEBUG then drawDebug() end
end

-- Draws a visible arrow in the editor (and in-game) showing
-- the center point and push direction for every force zone.
function drawDebug()
    for i = 1, #zoneLocations do
        local loc    = zoneLocations[i]
        local trans  = GetLocationTransform(loc)
        local center = trans.pos
        local pushDir = VecNormalize(TransformToParentVec(trans, Vec(0, 1, 0)))

        -- Arrow shaft: center → center + pushDir * RADIUS
        local tip  = VecAdd(center, VecScale(pushDir, RADIUS))
        -- Two small cross-lines at the tip to form an arrowhead
        -- (use any perpendicular — cross with world up or world right)
        local perp1 = VecNormalize(VecCross(pushDir, Vec(0, 1, 0)))
        if VecLength(perp1) < 0.01 then
            perp1 = VecNormalize(VecCross(pushDir, Vec(1, 0, 0)))
        end
        local perp2 = VecNormalize(VecCross(pushDir, perp1))
        local headSize = RADIUS * 0.25
        local head1 = VecAdd(tip, VecScale(VecAdd(VecScale(perp1, 1), VecScale(pushDir, -1)), headSize))
        local head2 = VecAdd(tip, VecScale(VecAdd(VecScale(perp1, -1), VecScale(pushDir, -1)), headSize))
        local head3 = VecAdd(tip, VecScale(VecAdd(VecScale(perp2, 1), VecScale(pushDir, -1)), headSize))
        local head4 = VecAdd(tip, VecScale(VecAdd(VecScale(perp2, -1), VecScale(pushDir, -1)), headSize))

        -- Bright cyan shaft
        DebugLine(center, tip,   0, 1, 1)
        -- Arrowhead lines
        DebugLine(tip, head1,    0, 1, 1)
        DebugLine(tip, head2,    0, 1, 1)
        DebugLine(tip, head3,    0, 1, 1)
        DebugLine(tip, head4,    0, 1, 1)

        -- Circle outline at the base showing the radius
        local segments = 16
        for s = 0, segments - 1 do
            local a1 = (s / segments) * math.pi * 2
            local a2 = ((s + 1) / segments) * math.pi * 2
            local p1 = VecAdd(center, Vec(math.cos(a1) * RADIUS, 0, math.sin(a1) * RADIUS))
            local p2 = VecAdd(center, Vec(math.cos(a2) * RADIUS, 0, math.sin(a2) * RADIUS))
            DebugLine(p1, p2, 0, 0.6, 0.6)
        end
    end
end
