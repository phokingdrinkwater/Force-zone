#version 2
#include "script/common.lua"

-- make sure to add to the translate file in the data folder when adding more maps
-- since they gotta be a translated file now
-- the name of the map should match the translate before it is translated
--
-- for example
--
-- if the name of a map is "planet"
-- then in the translate it should be..
-- map.planet        "Planetary"
--
-- NOT 
-- map.planetary    "Planet"

function server.init()
    -- the mod name should be the exact same as the ones inside the spawn.txt
    -- no spaces or special characters
    ModName = "phokingsimple"
    -- Clear persistent strings first so repeated loads don't accumulate duplicates
    SetString("level.vehicle_sumo_map_addons_"..ModName, "", true)
    SetString("level.vehicle_sumo_addons", "", true)
    server.addOnInitialize() -- keep map adding below this function
    

    
    -- should have an xml named the same
    -- modes are: Sumo (sumo), Zone Rush (rush), Bomb tag (tag), Crown Thief (crown), Coin Grabbers (coin), Goals (goals)
    server.addMap("simplephoking","sumo,rush,tag,crown")
end


-- adds one map
-- put multiple to add more than one
-- Example: server.addMap("grid","sumo,rush,tag")

function server.addMap(name,modes)
    local key = GetString("level.vehicle_sumo_map_addons_"..ModName)
    SetString("level.vehicle_sumo_map_addons_"..ModName, key..":"..name..","..modes,true)
end

-- not implemented yet
function server.addVehicle(name)
    
end

function server.addOnInitialize()
    local key = GetString("level.vehicle_sumo_addons")
    SetString("level.vehicle_sumo_addons", key..","..ModName,true)
end
-- template version 2


--* Requirements

-- Mod name
-- Map name

-- Mod and Map name cannot be the same
-- No spaces or special characters

-- Level editor knowledge

-- Scripting knowledge


